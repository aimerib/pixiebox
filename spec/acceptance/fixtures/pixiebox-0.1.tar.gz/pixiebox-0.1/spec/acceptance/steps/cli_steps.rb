module CliSteps
  step 'I am in a project directory called :name' do |name|
    create_directory name
    cd name
  end

  step 'the test environment is setup' do
    send 'a mocked home directory'

    # stub tmp dir
    create_directory 'tmp'
    allow(Pixiebox::Os::CurrentOs.get).
      to receive(:tmp_dir).
      and_return("#{Pixiebox.root}/#{Aruba.config.working_directory}/tmp")

    # place tar from fixtures (like it was downloaded but it wasn't)
    allow_any_instance_of(Pixiebox::Utils::Packages).
      to receive(:download).
      and_return("#{Pixiebox.root}/#{Aruba.config.working_directory}/tmp/packages_v0.1.tar")

    copy '%/packages_v0.1.tar', 'tmp/packages_v0.1.tar'

    # stub packages directory
    #allow(Pixiebox).
    #  to receive(:packages_dir).
    #  and_return("#{Pixiebox.root}/#{Aruba.config.working_directory}/packages")
  end

  step 'pixiebox can be installed' do
    send 'docker is installed'

    stub_request(:any, Pixiebox::PACKAGES_INFO_URL).
      to_return(body: package_info_url_response, status: 200)

    stub_request(:any, 'https://api.github.com/repos/pixiebox/packages/tarball/v0.1').
      to_return(body: '', status: 200)
  end

  step 'pixiebox has been installed' do
    send 'pixiebox can be installed'

    run_simple('pixiebox install', fail_on_error: false)

    send 'I copy (a/the) directory from ":source" to ":destination"', 'packages/boxes', 'packages'
    send 'I copy (a/the) directory from ":source" to ":destination"', 'packages/services', 'packages'
    send 'I copy (a/the) directory from ":source" to ":destination"', 'packages/shell', 'packages'
  end

  def package_info_url_response
    '{
      "url": "https://api.github.com/repos/aimerib/packages/releases/24748753",
      "assets_url": "https://api.github.com/repos/aimerib/packages/releases/24748753/assets",
      "upload_url": "https://uploads.github.com/repos/aimerib/packages/releases/24748753/assets{?name,label}",
      "html_url": "https://github.com/aimerib/packages/releases/tag/v0.1",
      "id": 24748753,
      "node_id": "MDc6UmVsZWFzZTI0NzQ4NzUz",
      "tag_name": "v0.1",
      "target_commitish": "master",
      "name": "First release",
      "draft": false,
      "author": {
        "login": "aimerib",
        "id": 26142232,
        "node_id": "MDQ6VXNlcjI2MTQyMjMy",
        "avatar_url": "https://avatars0.githubusercontent.com/u/26142232?v=4",
        "gravatar_id": "",
        "url": "https://api.github.com/users/aimerib",
        "html_url": "https://github.com/aimerib",
        "followers_url": "https://api.github.com/users/aimerib/followers",
        "following_url": "https://api.github.com/users/aimerib/following{/other_user}",
        "gists_url": "https://api.github.com/users/aimerib/gists{/gist_id}",
        "starred_url": "https://api.github.com/users/aimerib/starred{/owner}{/repo}",
        "subscriptions_url": "https://api.github.com/users/aimerib/subscriptions",
        "organizations_url": "https://api.github.com/users/aimerib/orgs",
        "repos_url": "https://api.github.com/users/aimerib/repos",
        "events_url": "https://api.github.com/users/aimerib/events{/privacy}",
        "received_events_url": "https://api.github.com/users/aimerib/received_events",
        "type": "User",
        "site_admin": false
      },
      "prerelease": false,
      "created_at": "2020-03-22T14:00:16Z",
      "published_at": "2020-03-22T14:08:20Z",
      "assets": [],
      "tarball_url": "https://api.github.com/repos/aimerib/packages/tarball/v0.1",
      "zipball_url": "https://api.github.com/repos/aimerib/packages/zipball/v0.1",
      "body": "Initial package for pixiebox"
      }'
  end
end


RSpec.configure do |config|
  config.include CliSteps
end
