#!/bin/bash
#
# setup pixiebox proxies
#
# normally extensions are here this is just a test stub