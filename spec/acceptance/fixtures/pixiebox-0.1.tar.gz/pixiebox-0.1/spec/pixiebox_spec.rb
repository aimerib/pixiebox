describe Pixiebox do
  it 'has a version number' do
    expect(Pixiebox::VERSION).not_to be nil
  end
end
