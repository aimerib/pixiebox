docker login
docker tag <image_name> pixiebox/<image_name>
docker push pixiebox/<image_name>